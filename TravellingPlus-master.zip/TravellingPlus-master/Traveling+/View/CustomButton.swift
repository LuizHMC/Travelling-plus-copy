//
//  CustomButton.swift
//  Traveling+
//
//  Created by Leonardo Oliveira on 14/05/19.
//  Copyright © 2019 Leonardo Oliveira. All rights reserved.
//

import UIKit

@IBDesignable
class CustomButton: UIButton {
    
    override func draw(_ rect: CGRect) {
        self.layer.masksToBounds = true
        self.layer.cornerRadius = 5.0
//        self.layer.borderWidth = 1
//        self.layer.borderColor = UIColor(red: 255, green: 255, blue: 255).cgColor
        
    }
}
