//
//  DestinationTableViewController.swift
//  Traveling+
//
//  Created by Leonardo Oliveira on 10/05/19.
//  Copyright © 2019 Leonardo Oliveira. All rights reserved.
//

import UIKit
import CoreData

class DestinationTableViewController: UITableViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    @IBOutlet weak var navigationName: UINavigationItem!
    @IBOutlet weak var changeCountryBtn: UIBarButtonItem!
    
    let preferredLanguage = NSLocale.preferredLanguages[0]
    
    public var data: [Destination] = []
    var context: NSManagedObjectContext?
    
    var destination: String = "Brazil 🇧🇷"
    var index: Int = 1
    
    var info: [String] = []
    var infoText: [String] = []
    
    var texts: [String] = []
    
    let defaults = UserDefaults()
    
    var selectedTitle = " "
    var selectedImage: UIImage!
    var selectedText = " "
    
    var color: [CGColor] = [#colorLiteral(red: 0.1098039216, green: 0.5529411765, blue: 0.9411764706, alpha: 1),#colorLiteral(red: 0.1058823529, green: 0.5803921569, blue: 0.5215686275, alpha: 1),#colorLiteral(red: 0.6392156863, green: 0.003921568627, blue: 0, alpha: 1),#colorLiteral(red: 1, green: 0.4588235294, blue: 0, alpha: 1),#colorLiteral(red: 0.6392156863, green: 0.003921568627, blue: 0, alpha: 1),#colorLiteral(red: 0.1803921569, green: 0.3960784314, blue: 0.8274509804, alpha: 1)]
    
    var iconImage: UIImage!
    
    var imageName: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        buildTable()
    }
    
    public func buildTable(){
        destination = defaults.string(forKey: "destination")!
        
        imageName = destination
        
        if imageName == "Brasil 🇧🇷"{
            imageName = "Brazil 🇧🇷"
            
        } else if imageName == "Colômbia 🇨🇴"{
            imageName = "Colombia 🇨🇴"
            
        } else if imageName == "Perú 🇵🇪"{
            imageName = "Peru 🇵🇪"
            
        } else if imageName == "Uruguai 🇺🇾"{
            imageName = "Uruguay 🇺🇾"
        }
        
        navigationName.title = "To " + imageName
        
        fetchData()
        
        tableView.reloadData()
        tableView.tableFooterView = UIView(frame: CGRect(x: 0, y: 0, width: 0, height: 1))
    }
    
    func fetchData(){
        do{
            
            info = []
            infoText = []
            
            data = try context!.fetch(Destination.fetchRequest())
            
            for i in 0...5{
                
                if data[i].name == destination{
                    index = i
                }
            }
            
            if data[index].infoText1! != "NULL"{
                info.append(data[index].infoTitle1!)
                infoText.append(data[index].infoText1!)
            }
            
            if data[index].infoText2! != "NULL"{
                info.append(data[index].infoTitle2!)
                infoText.append(data[index].infoText2!)
            }
            
            if data[index].infoText3! != "NULL"{
                info.append(data[index].infoTitle3!)
                infoText.append(data[index].infoText3!)
            }
            
            if data[index].infoText4! != "NULL"{
                info.append(data[index].infoTitle4!)
                infoText.append(data[index].infoText4!)
            }
            
            if data[index].infoText5! != "NULL"{
                info.append(data[index].infoTitle5!)
                infoText.append(data[index].infoText5!)
            }
            
            if data[index].infoText6! != "NULL"{
                info.append(data[index].infoTitle6!)
                infoText.append(data[index].infoText6!)
            }
            
            if data[index].infoText7! != "NULL"{
                info.append(data[index].infoTitle7!)
                infoText.append(data[index].infoText7!)
            }
            
            if data[index].infoText8! != "NULL"{
                info.append(data[index].infoTitle8!)
                infoText.append(data[index].infoText8!)
            }
            
            if data[index].infoText9! != "NULL"{
                info.append(data[index].infoTitle9!)
                infoText.append(data[index].infoText9!)
            }
            
            if data[index].infoText10! != "NULL"{
                info.append(data[index].infoTitle10!)
                infoText.append(data[index].infoText10!)
            }
            
            tableView.reloadData()
            
        } catch{
            print(error.localizedDescription)
        }
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 2
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if preferredLanguage.starts(with: "pt"){
            
            if imageName == "Argentina 🇦🇷" || imageName == "Colombia 🇨🇴"{
               navigationName.title = "Para a " + destination
                
            } else{
                navigationName.title = "Para o " + destination
            }
            
        } else if preferredLanguage.starts(with: "es"){
            navigationName.title = "Para " + destination
            
        }
        
        
        if indexPath.row == 0{
            let cell = tableView.dequeueReusableCell(withIdentifier: "destinationTableViewCell", for: indexPath) as! DestinationTableViewCell
            cell.collectionView.tag = indexPath.row
            cell.collectionView.delegate = self
            cell.collectionView.dataSource = self
            
            if preferredLanguage.starts(with: "pt"){
                cell.generalWarningsLabel.text = "Avisos gerais"
                cell.subtitleLabel.text = "Mantenha-se atualizado."
                cell.seeAllBtn.setTitle("Ver todo", for: .normal)
                
                
            } else if preferredLanguage.starts(with: "es"){
                cell.generalWarningsLabel.text = "Avisos generales"
                cell.subtitleLabel.text = "Manténgase actualizado."
                cell.seeAllBtn.setTitle("Ver todo", for: .normal)
                
            }
            
            cell.collectionView.reloadData()
            
            return cell
            
        } else if indexPath.row == 1{
            let cell = tableView.dequeueReusableCell(withIdentifier: "tipsTableViewCell", for: indexPath) as! TipsTableViewCell
            cell.tipsCollectionView.tag = indexPath.row
            cell.tipsCollectionView.delegate = self
            cell.tipsCollectionView.dataSource = self
            // cell.collectionView.reloadData()
            
            
            if preferredLanguage.starts(with: "pt"){
                cell.tipLabel.text = "Biblioteca de dicas"
                cell.subtitleLabel.text = "Conheça as peculiaridades do seu destino."
                
                
            } else if preferredLanguage.starts(with: "es"){
                cell.tipLabel.text = "Biblioteca de consejos"
                cell.subtitleLabel.text = "Conozca las peculiaridades de su destino."
                
            }
            
            cell.tipsCollectionView.reloadData()
            
            return cell
            
        } else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "destinationTableViewCell", for: indexPath) as! DestinationTableViewCell
            return cell
        }
    }
    
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {

        if indexPath.row == 1{

            var cell = info.count / 2
            let rest = info.count % 2

            if rest != 0{

                cell = cell + rest

            }

            let height = 61 + 10 + (110*(cell))

            return CGFloat(height)

        } else{

            let width = UIScreen.main.bounds.width
            let height = (width / 2.125) + 61

            return CGFloat(height)

        }
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        if collectionView.tag == 0 {
            return 3
            
        } else if collectionView.tag == 1 {
            return info.count
            
        } else{
            return 3
        }
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if collectionView.tag == 0 {
            let cellCollection = collectionView.dequeueReusableCell(withReuseIdentifier: "generalWarningCollectionViewCell", for: indexPath) as! WarningsCollectionViewCell
            
            if indexPath.row == 0{
                cellCollection.titleLabel.text = data[index].warningTitle1!
                cellCollection.textLabel.text = data[index].warningSubtitle1!
                cellCollection.textAuxiliar = data[index].warningText1!
                texts.append(cellCollection.textAuxiliar)
                
            } else if indexPath.row == 1{
                cellCollection.titleLabel.text = data[index].warningTitle2!
                cellCollection.textLabel.text = data[index].warningSubtitle2!
                cellCollection.textAuxiliar = data[index].warningText2!
                texts.append(cellCollection.textAuxiliar)
                
            } else if indexPath.row == 2{
                cellCollection.titleLabel.text = data[index].warningTitle3!
                cellCollection.textLabel.text = data[index].warningSubtitle3!
                cellCollection.textAuxiliar = data[index].warningText3!
                texts.append(cellCollection.textAuxiliar)
            }
            
            cellCollection.layer.masksToBounds = true
            cellCollection.warningView.layer.cornerRadius = 10.0
            cellCollection.warningView.layer.borderColor = color[index]
            cellCollection.warningView.layer.borderWidth = 2.0
            cellCollection.layer.cornerRadius = 10.0
            cellCollection.layer.shadowOpacity = 0.8
            cellCollection.layer.shadowRadius = 3.0
            cellCollection.layer.shadowOffset = CGSize(width: 1.0, height: 1.0)
            cellCollection.layer.shadowColor = UIColor(red: 157/255, green: 157/255, blue: 157/255, alpha: 1.0).cgColor
            
            cellCollection.imageView.image = UIImage(named: "Generalwarningicon.pdf")
            // cellCollection.degradeView.image = UIImage(named: "\(destination) \(indexPath.row+1).pdf")
            
            return cellCollection
            
        } else if collectionView.tag == 1 {
            let cellCollection = collectionView.dequeueReusableCell(withReuseIdentifier: "tipsCollectionViewCell", for: indexPath) as! TipsCollectionViewCell
            
            cellCollection.layer.masksToBounds = true
            cellCollection.tipsView.layer.cornerRadius = 10.0
            cellCollection.layer.cornerRadius = 10.0
            cellCollection.layer.shadowOpacity = 0.8
            cellCollection.layer.shadowRadius = 3.0
            cellCollection.layer.shadowOffset = CGSize(width: 1.0, height: 1.0)
            cellCollection.layer.shadowColor = UIColor(red: 157/255, green: 157/255, blue: 157/255, alpha: 1.0).cgColor
            
            let destinationDefaults = defaults.string(forKey: "destination")
            destination = destinationDefaults!
            
            cellCollection.imageView.image = UIImage(named: "\(imageName!) \(indexPath.row+1).pdf")
            cellCollection.titleLabel.text = info[indexPath.row]
            cellCollection.textAuxiliar = infoText[indexPath.row]
            // texts.append(cellCollection.textAuxiliar)
            
            return cellCollection
            
        } else{
            return UICollectionViewCell()
            
        }
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if collectionView.tag == 1 {
        
            return CGSize(width: self.view.frame.size.width/2.36, height: self.view.frame.size.height/8.69)
        
        } else{
            
            return CGSize(width: self.view.frame.size.width/1.56, height: self.view.frame.size.height/4.7)
        }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "destinationSegue"{
            
            selectedTitle = (sender as! WarningsCollectionViewCell).titleLabel.text!
            selectedText = (sender as! WarningsCollectionViewCell).textAuxiliar!
            // selectedText = (sender as! WarningsCollectionViewCell).textLabel.text!
            
            let destinationViewController = segue.destination as! CardViewController
            destinationViewController.titleLabel = selectedTitle
            destinationViewController.color = "black"
            destinationViewController.text = selectedText
            destinationViewController.borderColor = color[index]
            destinationViewController.parentVC = self
            tabBarController?.tabBar.isHidden = true
            
        } else if segue.identifier == "tipsSegue"{
            
            selectedTitle = (sender as! TipsCollectionViewCell).titleLabel.text!
            selectedText = (sender as! TipsCollectionViewCell).textAuxiliar!
            selectedImage = (sender as! TipsCollectionViewCell).imageView.image!
            
            let destinationViewController = segue.destination as! CardViewController
            destinationViewController.titleLabel = selectedTitle
            destinationViewController.text = selectedText
            destinationViewController.image = UIImage(named: "\(imageName!) 1.pdf")
            destinationViewController.parentVC = self
            destinationViewController.imageName = imageName
            tabBarController?.tabBar.isHidden = true
            
        } else if segue.identifier == "changeDestinationSegue"{
            
            let destinationViewController = segue.destination as! SettingsViewController
            destinationViewController.destinationVC = self
            destinationViewController.text = destination
            destinationViewController.image =  UIImage(named: "\(imageName!) 1.pdf")
            destinationViewController.imageName = imageName
            tabBarController?.tabBar.isHidden = true
        
        } else if segue.identifier == "seeAllSegue2"{
            
            let destinationViewController = segue.destination as! SeeAllTableViewController
            destinationViewController.titleLabel = [data[index].warningTitle1!, data[index].warningTitle2!, data[index].warningTitle3!]
            destinationViewController.text = texts
            destinationViewController.destinationVC = self
            destinationViewController.destinationCountry = color[index]
            destinationViewController.imageName = imageName
            destinationViewController.data2 = data
            destinationViewController.index = index
            destinationViewController.borderColor = color[index]
        }
        
    }
    
    
}
