//
//  Disclaimer+CoreDataProperties.swift
//  Traveling+
//
//  Created by Zewu Chen on 24/05/19.
//  Copyright © 2019 Leonardo Oliveira. All rights reserved.
//
//

import Foundation
import CoreData


extension Disclaimer {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Disclaimer> {
        return NSFetchRequest<Disclaimer>(entityName: "Disclaimer")
    }

    @NSManaged public var text: String?

}
