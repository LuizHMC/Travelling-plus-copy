//
//  DisclaimerViewController.swift
//  Traveling+
//
//  Created by Leonardo Oliveira on 24/05/19.
//  Copyright © 2019 Leonardo Oliveira. All rights reserved.
//

import UIKit
import CoreData

class DisclaimerViewController: UIViewController {

    @IBOutlet weak var disclaimerTextView: UITextView!
    
    public var data: [Disclaimer] = []
    var context: NSManagedObjectContext?
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        fetchData()
        
        disclaimerTextView.text = data[0].text
    }
    
    func fetchData(){
        do{
            
            data = try context!.fetch(Disclaimer.fetchRequest())
            
            
        } catch{
            print(error.localizedDescription)
        }
    }

    
    
}
