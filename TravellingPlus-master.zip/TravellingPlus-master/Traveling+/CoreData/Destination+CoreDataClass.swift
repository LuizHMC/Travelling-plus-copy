//
//  Destination+CoreDataClass.swift
//  Traveling+
//
//  Created by Zewu Chen on 14/05/19.
//  Copyright © 2019 Zewu Chen. All rights reserved.
//

import Foundation
import CoreData


public class Destination: NSManagedObject {

}
