//
//  TipsCollectionViewCell.swift
//  Traveling+
//
//  Created by Leonardo Oliveira on 13/05/19.
//  Copyright © 2019 Leonardo Oliveira. All rights reserved.
//

import UIKit

class TipsCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var tipsView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    
    public var textAuxiliar: String!
}
