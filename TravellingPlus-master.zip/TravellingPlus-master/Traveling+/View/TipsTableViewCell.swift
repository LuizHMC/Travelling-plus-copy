//
//  TipsTableViewCell.swift
//  Traveling+
//
//  Created by Leonardo Oliveira on 15/05/19.
//  Copyright © 2019 Leonardo Oliveira. All rights reserved.
//

import UIKit

class TipsTableViewCell: UITableViewCell {
    
    @IBOutlet weak var tipsCollectionView: UICollectionView!
    @IBOutlet weak var tipLabel: UILabel!
    @IBOutlet weak var subtitleLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
