//
//  WarningsCollectionViewCell.swift
//  Traveling+
//
//  Created by Leonardo Oliveira on 10/05/19.
//  Copyright © 2019 Leonardo Oliveira. All rights reserved.
//

import UIKit

class WarningsCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var warningView: UIView!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var textLabel: UILabel!
    @IBOutlet weak var degradeView: UIImageView!
    
    public var textAuxiliar: String!
    
}
