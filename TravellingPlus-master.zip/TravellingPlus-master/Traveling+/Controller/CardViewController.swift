//
//  CardViewController.swift
//  Traveling+
//
//  Created by Leonardo Oliveira on 15/05/19.
//  Copyright © 2019 Leonardo Oliveira. All rights reserved.
//

import UIKit

class CardViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    var titleLabel: String!
    var subTitle: String!
    var text: String!
    var image: UIImage!
    var parentVC: UITableViewController!
    var color = "white"
    var borderColor: CGColor?
    var imageName: String = ""
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
      let cellCollection = collectionView.dequeueReusableCell(withReuseIdentifier: "cardCollectionViewCell", for: indexPath) as! CardCollectionViewCell
        
        cellCollection.layer.masksToBounds = true
        cellCollection.cardView.layer.cornerRadius = 10.0
        cellCollection.cardView.layer.cornerRadius = 10.0
        cellCollection.layer.cornerRadius = 10.0
        cellCollection.layer.shadowOpacity = 0.8
        cellCollection.layer.shadowRadius = 3.0
        cellCollection.layer.shadowOffset = CGSize(width: 1.0, height: 1.0)
        cellCollection.layer.shadowColor = UIColor(red: 157/255, green: 157/255, blue: 157/255, alpha: 1.0).cgColor
        
        cellCollection.titleLabel.text = titleLabel
        cellCollection.textView.text = text
        cellCollection.degradeView.image = UIImage(named: "\(imageName) 1.pdf")
        cellCollection.backBtn.setImage(UIImage(named: "X\(color).pdf"), for: .normal)
        
        if color != "white"{
            cellCollection.titleLabel.textColor = UIColor.black
            cellCollection.iconImage.image = UIImage(named: "Generalwarningicon.pdf")
            cellCollection.cardView.layer.borderWidth = 5.0
            cellCollection.cardView.layer.borderColor = borderColor
            cellCollection.backBtn.tintColor = UIColor.black
        }
        
        return cellCollection
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView.delegate = self
        collectionView.dataSource = self
        
        collectionView.reloadData()
    }
    
    @IBAction func backBtnPressed(_ sender: Any) {
        parentVC.tabBarController?.tabBar.isHidden = false
        dismiss(animated: true, completion: nil)
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
