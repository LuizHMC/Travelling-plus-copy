//
//  NationalityTableViewController.swift
//  Traveling+
//
//  Created by Leonardo Oliveira on 10/05/19.
//  Copyright © 2019 Leonardo Oliveira. All rights reserved.
//

import UIKit
import CoreData

class NationalityTableViewController: UITableViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    @IBOutlet weak var navigationName: UINavigationItem!
    
    let preferredLanguage = NSLocale.preferredLanguages[0]
    
    public var data: [Country] = []
    var context: NSManagedObjectContext?
    
    var country: String = "Brazil 🇧🇷"
    var index: Int = 1
    
    var categories = ["Passport", "Visa", "Entry Requirements"]
    
    var seeAllDic: [String: String] = [:]
    
    var passportTitles = ["Adult documents", "Underage documents", "Procedure", "Main location", "Others locations", "Cost", "Validity", "Others"]
    
    var passportJSONTitles = ["documentsAdults", "documentsMinors", "procedure", "location1", "locations2", "cost", "vality", "others"]
    
    var visaTitles = ["Visa requirement"]
    var visaJSONTitles = ["visa"]
    
    var entryRequirementsTitles = ["Necessary documents", "Vaccines"]
    var entryRequirementsJSONTitles = ["Vaccines"]
    
    let defaults = UserDefaults()
    
    var selectedTitle = " "
    var selectedSubtitle = " "
    var selectedText = " "
    
    var isOrigin: Bool = true
    
    var icon: UIImage!
    var titles: [String] = []
    var texts: [String] = []
    
    var imageName: String = "Brazil 🇧🇷"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        buildTable()
    }
    
    public func buildTable(){
        country = defaults.string(forKey: "country")!
        
        imageName = country
        
        if imageName == "Brasil 🇧🇷"{
            imageName = "Brazil 🇧🇷"
            
        } else if imageName == "Colômbia 🇨🇴"{
            imageName = "Colombia 🇨🇴"
            
        } else if imageName == "Perú 🇵🇪"{
            imageName = "Peru 🇵🇪"
            
        } else if imageName == "Uruguai 🇺🇾"{
            imageName = "Uruguay 🇺🇾"
        }
        
        navigationName.title = "From " + imageName
        
        fetchData()
        
        tableView.reloadData()
        tableView.tableFooterView = UIView(frame: CGRect(x: 0, y: 0, width: 0, height: 1))
    }
    
    
    func fetchData(){
        do{
            
            data = try context!.fetch(Country.fetchRequest())
            
            for i in 0...5{
                
                if data[i].name == country{
                    index = i
                }
                
                print(data[i].name!)
                // countries.append(data[i].name!)
            }
            
            tableView.reloadData()
            
        } catch{
            print(error.localizedDescription)
        }
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 3
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "nationalityTableViewCell", for: indexPath) as! NationalityTableViewCell
        
        if preferredLanguage.starts(with: "pt"){
            
            if imageName == "Argentina 🇦🇷" || imageName == "Colombia 🇨🇴"{
                navigationName.title = "Da " + country
                
            } else{
                navigationName.title = "Do " + country
            }
            
            tabBarController?.tabBar.items![0].title = "Nacionalidade"
            tabBarController?.tabBar.items![1].title = "Destino"
            passportTitles = ["Documentos para adultos", "Documentos para menores", "Procedimento", "Localização principal", "Outras localizações", "Custo", "Validade", "Outros"]
            visaTitles = ["Requerimentos de visto"]
            entryRequirementsTitles = ["Documentos necessários", "Vacinas"]
            cell.seeAllBtn.setTitle("Ver tudo", for: .normal)
            
        } else if preferredLanguage.starts(with: "es"){
            navigationName.title = "Desde " + country
            tabBarController?.tabBar.items![0].title = "Nacionalidad"
            tabBarController?.tabBar.items![1].title = "Destino"
            passportTitles = ["Documentos de adultos", "Documentos menores de edad", "Procedimiento", "Lugar principal", "Otros lugares", "Costo", "Validad", "Otros"]
            visaTitles = ["Requisito de visado"]
            entryRequirementsTitles = ["Documentos necesarios", "Vacunas"]
            cell.seeAllBtn.setTitle("Ver todo", for: .normal)
            
        }
        
        if indexPath.row == 0{
            
            cell.titleLabel.text = "Passaport"
            cell.subtitleLabel.text = "Documents, procedures and more!"
            
            if preferredLanguage.starts(with: "pt"){
                cell.titleLabel.text = "Passaporte"
                cell.subtitleLabel.text = "Documentos, procedimentos e mais!"
                
                
            } else if preferredLanguage.starts(with: "es"){
                cell.titleLabel.text = "Pasaporte"
                cell.subtitleLabel.text = "Documentos, procedimientos y más!"
                
            }
            
            cell.seeAllBtn.tag = 0
            
            cell.collectionView.tag = indexPath.row
            cell.collectionView.delegate = self
            cell.collectionView.dataSource = self
        }
        
        if indexPath.row == 1{
            
            cell.titleLabel.text = "Visa"
            cell.subtitleLabel.text = "Do I need one to my destination?"
            
            if preferredLanguage.starts(with: "pt"){
                cell.titleLabel.text = "Visto"
                cell.subtitleLabel.text = "Preciso de um para meu destino?"
                
                
            } else if preferredLanguage.starts(with: "es"){
                cell.titleLabel.text = "Visa"
                cell.subtitleLabel.text = "¿Necesito uno para mi destino?"
                
            }
            
            cell.seeAllBtn.tag = 1
            
            cell.collectionView.tag = indexPath.row
            cell.collectionView.delegate = self
            cell.collectionView.dataSource = self
        }
        
        if indexPath.row == 2{
            
            cell.titleLabel.text = "Entry requirements"
            cell.subtitleLabel.text = "What to have when entering the destination."
            
            if preferredLanguage.starts(with: "pt"){
                cell.titleLabel.text = "Requisitos de entrada"
                cell.subtitleLabel.text = "O que ter em mãos entrando no destino."
                
                
            } else if preferredLanguage.starts(with: "es"){
                cell.titleLabel.text = "Requisitos de entrada"
                cell.subtitleLabel.text = "Qué tener en las manos entrando en el destino."
                
            }
            
            cell.seeAllBtn.tag = 2
            
            cell.collectionView.tag = indexPath.row
            cell.collectionView.delegate = self
            cell.collectionView.dataSource = self
        }
        
        cell.collectionView.reloadData()
        return cell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        if collectionView.tag == 0 {
            return passportTitles.count
            
        } else if collectionView.tag == 1 {
            return visaTitles.count
            
        } else if collectionView.tag == 2 {
            return entryRequirementsTitles.count
            
        } else{
            return 1
        }
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if collectionView.tag == 0 {
            let cellCollection = collectionView.dequeueReusableCell(withReuseIdentifier: "generalWarningCollectionViewCell", for: indexPath) as! WarningsCollectionViewCell
            
            cellCollection.layer.masksToBounds = true
            cellCollection.warningView.layer.cornerRadius = 10.0
            cellCollection.layer.cornerRadius = 10.0
            cellCollection.layer.shadowOpacity = 0.8
            cellCollection.layer.shadowRadius = 3.0
            cellCollection.layer.shadowOffset = CGSize(width: 1.0, height: 1.0)
            cellCollection.layer.shadowColor = UIColor(red: 157/255, green: 157/255, blue: 157/255, alpha: 1.0).cgColor
            
            cellCollection.titleLabel.text = passportTitles[indexPath.row]
            cellCollection.imageView.image = UIImage(named: "Passporticon.pdf")
            cellCollection.degradeView.image = UIImage(named: "\(imageName) \(indexPath.row+1).pdf")
            
            if indexPath.row == 0{
                cellCollection.textAuxiliar = data[index].documentsAdults!
                texts.append(cellCollection.textAuxiliar)
                
            } else if indexPath.row == 1{
                cellCollection.textAuxiliar = data[index].documentsMinors!
                texts.append(cellCollection.textAuxiliar)
                
            } else if indexPath.row == 2{
                cellCollection.textAuxiliar = data[index].procedure!
                texts.append(cellCollection.textAuxiliar)
                
            } else if indexPath.row == 3{
                cellCollection.textAuxiliar = data[index].location1!
                texts.append(cellCollection.textAuxiliar)
                
            } else if indexPath.row == 4{
                cellCollection.textAuxiliar = data[index].location2!
                
                if cellCollection.textAuxiliar == "NULL"{
                    cellCollection.textAuxiliar = "There's no others locations to do the procedure."
                }
                
                texts.append(cellCollection.textAuxiliar)
                
            } else if indexPath.row == 5{
                cellCollection.textAuxiliar = data[index].cost!
                texts.append(cellCollection.textAuxiliar)
                
            } else if indexPath.row == 6{
                cellCollection.textAuxiliar = data[index].vality!
                texts.append(cellCollection.textAuxiliar)
                
            } else if indexPath.row == 7{
                cellCollection.textAuxiliar = data[index].others!
                texts.append(cellCollection.textAuxiliar)
                
                if cellCollection.textAuxiliar == "NULL"{
                    cellCollection.textAuxiliar = "There's no others informations available."
                }
                
                texts.append(cellCollection.textAuxiliar)
            }
            
            return cellCollection
            
        } else if collectionView.tag == 1 {
            let cellCollection = collectionView.dequeueReusableCell(withReuseIdentifier: "generalWarningCollectionViewCell", for: indexPath) as! WarningsCollectionViewCell
            
            cellCollection.layer.masksToBounds = true
            cellCollection.warningView.layer.cornerRadius = 10.0
            cellCollection.layer.cornerRadius = 10.0
            cellCollection.layer.shadowOpacity = 0.8
            cellCollection.layer.shadowRadius = 3.0
            cellCollection.layer.shadowOffset = CGSize(width: 1.0, height: 1.0)
            cellCollection.layer.shadowColor = UIColor(red: 157/255, green: 157/255, blue: 157/255, alpha: 1.0).cgColor
            
            cellCollection.imageView.image = UIImage(named: "Visaicon.pdf")
            cellCollection.degradeView.image = UIImage(named: "\(imageName) \(indexPath.row+1).pdf")
            cellCollection.titleLabel.text = visaTitles[indexPath.row]
            
            if indexPath.row == 0{
                cellCollection.textAuxiliar = data[index].visa!
            }
            
            return cellCollection
            
        } else if collectionView.tag == 2 {
            let cellCollection = collectionView.dequeueReusableCell(withReuseIdentifier: "generalWarningCollectionViewCell", for: indexPath) as! WarningsCollectionViewCell
            
            cellCollection.layer.masksToBounds = true
            cellCollection.warningView.layer.cornerRadius = 10.0
            cellCollection.layer.cornerRadius = 10.0
            cellCollection.layer.shadowOpacity = 0.8
            cellCollection.layer.shadowRadius = 3.0
            cellCollection.layer.shadowOffset = CGSize(width: 1.0, height: 1.0)
            cellCollection.layer.shadowColor = UIColor(red: 157/255, green: 157/255, blue: 157/255, alpha: 1.0).cgColor
            
            cellCollection.imageView.image = UIImage(named: "Entryrequirementsicon.pdf")
            cellCollection.degradeView.image = UIImage(named: "\(imageName) \(indexPath.row+1).pdf")
            cellCollection.titleLabel.text = entryRequirementsTitles[indexPath.row]
            
            if indexPath.row == 0{
                
                if preferredLanguage.starts(with: "pt"){
                    cellCollection.textAuxiliar = "Você pode entrar em seu destino apenas com seu documento de identidade. Se preferir, você também pode usar o seu passaporte."
                    
                    
                } else if preferredLanguage.starts(with: "es"){
                    cellCollection.textAuxiliar = "Usted puede entrar en su destino sólo con su documento de identidad. Si lo prefiere, también puede utilizar su pasaporte."
                    
                } else{
                    cellCollection.textAuxiliar = "You can enter your destination country only with your ID. If you prefer, you may also use your passport."
                }
                
            } else if indexPath.row == 1{
                
                var destination: String = ""
                
                destination = defaults.string(forKey: "destination")!
                
                if destination == "Colômbia 🇨🇴" || destination == "Colombia 🇨🇴"{
                    
                    if preferredLanguage.starts(with: "pt"){
                        cellCollection.textAuxiliar = "Requisito do Certificado Internacional de Vacinação contra a Febre Amarela na Colômbia. A vacina é obrigatória para a entrada na Colômbia."
                        
                        
                    } else if preferredLanguage.starts(with: "es"){
                        cellCollection.textAuxiliar = "Requisito del Certificado Internacional de Vacunación contra la Fiebre Amarilla en Colombia. La vacuna es obligatoria para la entrada en Colombia."
                        
                    } else{
                        cellCollection.textAuxiliar = "Requirement of the International Certificate of Vaccination or Prophylaxis against Yellow Fever in Colombia. The vaccine is mandatory for entering Colombia."
                    }
                    
                } else{
                    cellCollection.textAuxiliar = data[index].vaccines!
                }
            }
            
            return cellCollection
            
        } else{
            return UICollectionViewCell()
            
        }
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: self.view.frame.size.width/1.56, height: self.view.frame.size.height/4.7)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "nationalitySegue"{
            
            selectedTitle = (sender as! WarningsCollectionViewCell).titleLabel.text!
            selectedText = (sender as! WarningsCollectionViewCell).textAuxiliar!
            // selectedText = (sender as! WarningsCollectionViewCell).textLabel.text!
            
            let destination = segue.destination as! CardViewController
            destination.titleLabel = selectedTitle
            destination.text = selectedText
            destination.image = UIImage(named: "\(imageName) 1.pdf")
            destination.imageName = imageName
            destination.parentVC = self
            
            tabBarController?.tabBar.isHidden = true
            
        } else if segue.identifier == "changeNationalitySegue"{
            
            let destinationVC = segue.destination as! SettingsViewController
            destinationVC.nationalityVC = self
            destinationVC.text = country
            destinationVC.image =  UIImage(named: "\(imageName) 1.pdf")
            destinationVC.imageName = imageName
            tabBarController?.tabBar.isHidden = true
            
        } else if segue.identifier == "seeAllSegue1"{
            
            var largeTitle: String!
            var colors: [Int] = [1, 3, 2, 4, 5, 5, 4, 3, 2, 1]
            
            if preferredLanguage.starts(with: "pt"){
                
                categories = ["Passaporte", "Visto", "Requisitos de entrada"]
                
            } else if preferredLanguage.starts(with: "es"){
                categories = ["Pasaporte", "Visa", "Requisitos de entrada"]
            }
            
            if (sender as! UIButton).tag == 0{
                
                for i in 0..<passportTitles.count{
                    
                    seeAllDic[passportTitles[i]] = "\(imageName) \(colors[i]).pdf"
                }
                
                titles = passportTitles
                icon = UIImage(named: "Passporticon.pdf")
                largeTitle = categories[0]
                
            } else if (sender as! UIButton).tag == 1{
                
                for i in 0..<visaTitles.count{
                    seeAllDic[visaTitles[i]] = "\(imageName) \(colors[i]).pdf"
                }
                
                titles = visaTitles
                icon = UIImage(named: "Visaicon.pdf")
                largeTitle = categories[1]
                
            } else if (sender as! UIButton).tag == 2{
                
                for i in 0..<entryRequirementsTitles.count{
                    seeAllDic[entryRequirementsTitles[i]] = "\(imageName) \(colors[i]).pdf"
                }
                
                titles = entryRequirementsTitles
                icon = UIImage(named: "Entryrequirementsicon.pdf")
                largeTitle = categories[2]
            }
            
            let destinationViewController = segue.destination as! SeeAllTableViewController
            destinationViewController.navbarName = largeTitle
            destinationViewController.titleLabel = titles
            destinationViewController.dicImage = seeAllDic
            destinationViewController.text = texts
            destinationViewController.nationalityCountry = self.country
            destinationViewController.iconImage = icon
            destinationViewController.nationalityCountry = country
            destinationViewController.nationalityVC = self
            destinationViewController.data1 = data
            destinationViewController.index = index
            destinationViewController.imageName = imageName
        }
    }
    
}
