//
//  CustomView.swift
//  Traveling+
//
//  Created by Leonardo Oliveira on 14/05/19.
//  Copyright © 2019 Leonardo Oliveira. All rights reserved.
//

import UIKit

@IBDesignable
class CustomView: UIView {
    
    override func draw(_ rect: CGRect) {
        self.layer.masksToBounds = true
        self.layer.cornerRadius = 10.0
        self.layer.borderColor = UIColor.black.cgColor
        self.layer.borderWidth = 1.0
        //        self.layer.borderWidth = 1
        //        self.layer.borderColor = UIColor(red: 255, green: 255, blue: 255).cgColor
        
//        cell.layer.masksToBounds = true
//        cell.warningView.layer.cornerRadius = 10.0
//        cell.warningView.layer.borderColor = UIColor.black.cgColor
//        cell.warningView.layer.borderWidth = 0.5
//        cell.layer.cornerRadius = 10.0
//        cell.layer.shadowOpacity = 0.8
//        cell.layer.shadowRadius = 3.0
//        cell.layer.shadowOffset = CGSize(width: 1.0, height: 1.0)
//        cell.layer.shadowColor = UIColor(red: 157/255, green: 157/255, blue: 157/255, alpha: 1.0).cgColor
        
    }
}
