//
//  MainViewController.swift
//  Traveling+
//
//  Created by Leonardo Oliveira on 09/05/19.
//  Copyright © 2019 Leonardo Oliveira. All rights reserved.
//

import UIKit
import CoreData
import Foundation

class MainViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    public var data: [Country] = []
    
    let preferredLanguage = NSLocale.preferredLanguages[0]
    
    var countries: [String] = []
    
    var selected: String = ""
    var selectedNationality: Int = 0
    var selectedDestination: Int = 0
    
    var context: NSManagedObjectContext?
    
    @IBOutlet weak var nationalityLabel: UILabel!
    @IBOutlet weak var destinationLabel: UILabel!
    @IBOutlet weak var pickerView: UIPickerView!
    @IBOutlet weak var toolbar: UIToolbar!
    @IBOutlet weak var confiirmBtn: CustomButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if preferredLanguage.starts(with: "pt"){
            nationalityLabel.text = "Nacionalidade"
            destinationLabel.text = "Destino"
            confiirmBtn.setTitle("Confirmar", for: .normal)
            
            
        } else if preferredLanguage.starts(with: "es"){
            nationalityLabel.text = "Nacionalidad"
            destinationLabel.text = "Destino"
            confiirmBtn.setTitle("Confirmar", for: .normal)
            
        }
        
        pickerView.isHidden = true
        toolbar.isHidden = true
        
        pickerView.dataSource = self
        pickerView.delegate = self
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.hidePickerView))
        //tap.cancelsTouchesInView = false
        self.view.addGestureRecognizer(tap)
        

    }
    
    @objc func hidePickerView(){
        if pickerView != nil {
            pickerView.isHidden = true
            toolbar.isHidden = true
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        fetchData()
    }
    
    @IBAction func nacionalityBtnPressed(_ sender: Any) {
        
        pickerView.isHidden = false
        toolbar.isHidden = false
        selected = "nationality"
        pickerView.selectRow(selectedNationality, inComponent: 0, animated: false)
    }
    
    
    @IBAction func destinationBtnPressed(_ sender: Any) {
        
        pickerView.isHidden = false
        toolbar.isHidden = false
        selected = "destination"
        pickerView.selectRow(selectedDestination, inComponent: 0, animated: false)
    }
    
    func fetchData(){
        do{
            
            data = try context!.fetch(Country.fetchRequest())
            
            for i in 0...5{
                print(data[i].name!)
                countries.append(data[i].name!)
            }
            
            pickerView.reloadAllComponents()
            
        } catch{
            print(error.localizedDescription)
        }
    }
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        return countries.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return countries[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        if selected == "nationality"{
            
            nationalityLabel.text = countries[row]
            selectedNationality = row
            
        } else if selected == "destination"{
            
            destinationLabel.text = countries[row]
            selectedDestination = row
        }
    }
    
    @IBAction func doneBtn(_ sender: Any) {
        
        pickerView.isHidden = true
        toolbar.isHidden = true
    }
    
    
    @IBAction func confirmBtnPressed(_ sender: Any) {
        
        if nationalityLabel.text == "Nationality" || destinationLabel.text == "Destination" || nationalityLabel.text == "Nacionalidade" || destinationLabel.text == "Destino" || nationalityLabel.text == "Nacionalidad"{
            
            if preferredLanguage.starts(with: "pt"){
                
                let alert = UIAlertController(title: "Dados incompleto", message: "Você deve selecionar uma Nacionalidade e um Destino para continuar.", preferredStyle: UIAlertController.Style.alert)
                
                let fillLabelAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
                alert.addAction(fillLabelAction)
                self.present(alert, animated: true, completion: nil)
                
            } else if preferredLanguage.starts(with: "es"){
               
                let alert = UIAlertController(title: "Datos incompletos", message: "Usted debe seleccionar una nacionalidad y un destino para continuar.", preferredStyle: UIAlertController.Style.alert)
                
                let fillLabelAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
                alert.addAction(fillLabelAction)
                self.present(alert, animated: true, completion: nil)
                
            } else{
                let alert = UIAlertController(title: "Incomplete data", message: "You must input Nationality and Destination to continue.", preferredStyle: UIAlertController.Style.alert)
                
                let fillLabelAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
                alert.addAction(fillLabelAction)
                self.present(alert, animated: true, completion: nil)
            }
        
        } else{
            let defaults = UserDefaults()
            
            defaults.set(nationalityLabel.text, forKey: "country")
            defaults.set(destinationLabel.text, forKey: "destination")
            
            performSegue(withIdentifier: "confirmSegue", sender: self)
        }
    }
    
    
}
