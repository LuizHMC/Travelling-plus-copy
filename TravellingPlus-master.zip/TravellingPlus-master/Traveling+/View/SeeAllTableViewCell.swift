//
//  SeeAllTableViewCell.swift
//  Traveling+
//
//  Created by Leonardo Oliveira on 23/05/19.
//  Copyright © 2019 Leonardo Oliveira. All rights reserved.
//

import UIKit

class SeeAllTableViewCell: UITableViewCell {

    @IBOutlet weak var seeAllView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var iconImage: UIImageView!
    @IBOutlet weak var degradeView: UIImageView!
    
    public var textAuxiliar: String!

}
