//
//  MyTips+CoreDataProperties.swift
//  Traveling+
//
//  Created by Zewu Chen on 24/05/19.
//  Copyright © 2019 Leonardo Oliveira. All rights reserved.
//
//

import Foundation
import CoreData


extension MyTips {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<MyTips> {
        return NSFetchRequest<MyTips>(entityName: "MyTips")
    }

    @NSManaged public var title: String?
    @NSManaged public var text: String?
    @NSManaged public var country: String?

}
