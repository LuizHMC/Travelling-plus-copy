//
//  CardCollectionViewCell.swift
//  Traveling+
//
//  Created by Leonardo Oliveira on 15/05/19.
//  Copyright © 2019 Leonardo Oliveira. All rights reserved.
//

import UIKit

class CardCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var degradeView: UIImageView!
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var cardView: UIView!
    @IBOutlet weak var backBtn: UIButton!
    @IBOutlet weak var iconImage: UIImageView!
    
    
    
}
