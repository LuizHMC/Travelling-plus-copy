//
//  SettingsViewController.swift
//  Traveling+
//
//  Created by Leonardo Oliveira on 16/05/19.
//  Copyright © 2019 Leonardo Oliveira. All rights reserved.
//

import UIKit
import CoreData

class SettingsViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var textLabel: UILabel!
    @IBOutlet weak var toolbar: UIToolbar!
    @IBOutlet weak var pickerView: UIPickerView!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var settingsView: UIView!
    @IBOutlet weak var iconImageView: UIImageView!
    @IBOutlet weak var confirmBtn: CustomButton!
    
    var imageName: String = "Brazil 🇧🇷"
    
    let preferredLanguage = NSLocale.preferredLanguages[0]
    
    var text: String!
    var image: UIImage!
    
    var nationalityVC: NationalityTableViewController?
    var destinationVC: DestinationTableViewController?
    
    public var data: [Country] = []
    
    var countries: [String] = []
    var index: Int = 0
    
    var selected: String = ""
    var currentCountry: Int = 0
    var selectedDestination: Int = 0
    
    var context: NSManagedObjectContext?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        pickerView.isHidden = true
        toolbar.isHidden = true
        
        pickerView.dataSource = self
        pickerView.delegate = self
        
        context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        fetchData()
        
        settingsView.layer.cornerRadius = 10.0
        
        imageView.image = UIImage(named: "\(imageName) 1.pdf")
        textLabel.text = text
        pickerView.selectRow(index, inComponent: 0, animated: true)
        
        if nationalityVC != nil{
            
            titleLabel.text = "Change nationality"
            
            if self.preferredLanguage.starts(with: "pt"){
                titleLabel.text = "Trocar nacionalidade"
                self.confirmBtn.setTitle("Confirmar", for: .normal)
                
                
            } else if self.preferredLanguage.starts(with: "es"){
                titleLabel.text = "Cambiar nacionalidad"
                self.confirmBtn.setTitle("Confirmar", for: .normal)
            }
            
            iconImageView.image = UIImage(named: "Mycountryicon.pdf")
            
        } else{
            
            titleLabel.text = "Change destination"
            
            if self.preferredLanguage.starts(with: "pt"){
                titleLabel.text = "Trocar destino"
                
                
            } else if self.preferredLanguage.starts(with: "es"){
                titleLabel.text = "Cambiar destino"
            }
            
            iconImageView.image = UIImage(named: "Destinationicon.pdf")
        }
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.hidePickerView))
        self.view.addGestureRecognizer(tap)
        
    }
    
    @objc func hidePickerView(){
        if pickerView != nil {
            pickerView.isHidden = true
            toolbar.isHidden = true
        }
    }
    
    func fetchData(){
        do{
            
            data = try context!.fetch(Country.fetchRequest())
            
            for i in 0...5{
                countries.append(data[i].name!)
                
                if data[i].name == text{
                    index = i
                }
            }
            
            pickerView.reloadAllComponents()
            
        } catch{
            print(error.localizedDescription)
        }
    }
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        return countries.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return countries[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        textLabel.text = countries[row]
        currentCountry = row
    }
    
    
    @IBAction func nationalityBtnPressed(_ sender: Any) {
        pickerView.isHidden = false
        toolbar.isHidden = false
//        pickerView.selectRow(currentCountry, inComponent: 0, animated: false)
    }
    
    @IBAction func doneBtnPressed(_ sender: Any) {
        pickerView.isHidden = true
        toolbar.isHidden = true
    }
    
    @IBAction func backBtnPressed(_ sender: Any) {
        
        if nationalityVC != nil{
            self.nationalityVC!.tabBarController?.tabBar.isHidden = false
            
        } else{
            self.destinationVC!.tabBarController?.tabBar.isHidden = false
            // self.destinationVC!.tableView.reloadData()
        }
        
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func confirmBtnPressed(_ sender: Any) {
        
        let defaults = UserDefaults()
        
        if nationalityVC != nil{
            defaults.set(textLabel.text, forKey: "country")
            self.nationalityVC!.tabBarController?.tabBar.isHidden = false
            self.nationalityVC!.buildTable()
            
        } else{
            defaults.set(textLabel.text, forKey: "destination")
            self.destinationVC!.tabBarController?.tabBar.isHidden = false
            self.destinationVC!.buildTable()
        }
        
        dismiss(animated: true, completion: nil)
        
        // performSegue(withIdentifier: "confirmSegue", sender: self)
    }
    
}
