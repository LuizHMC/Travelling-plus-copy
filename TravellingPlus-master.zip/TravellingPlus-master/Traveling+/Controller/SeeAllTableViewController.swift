//
//  SeeAllTableViewController.swift
//  Traveling+
//
//  Created by Leonardo Oliveira on 23/05/19.
//  Copyright © 2019 Leonardo Oliveira. All rights reserved.
//

import UIKit

class SeeAllTableViewController: UITableViewController {
    
    var titleLabel: [String]!
    var text: [String]!
    var iconImage: UIImage!
    var dicImage: [String: String]!
    
    public var data1: [Country]!
    public var data2: [Destination]!
    
    @IBOutlet weak var navigationName: UINavigationItem!
    var navbarName: String!
    
    var nationalityVC: NationalityTableViewController?
    var destinationVC: DestinationTableViewController?
    
    var destinationCountry: CGColor!
    var nationalityCountry: String!
    
    var borderColor: CGColor?
    
    var imageName: String = "Brazil 🇧🇷"
    
    var index: Int!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        if nationalityVC != nil{
            navigationName.title = navbarName!
        }
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return titleLabel.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "seeAllCell", for: indexPath) as! SeeAllTableViewCell
        
        // let celll = tableView.cell

        cell.layer.masksToBounds = true
        cell.seeAllView.layer.cornerRadius = 10.0
        cell.seeAllView.layer.cornerRadius = 10.0
        cell.layer.cornerRadius = 10.0
        cell.layer.shadowOpacity = 0.8
        cell.layer.shadowRadius = 3.0
        cell.layer.shadowOffset = CGSize(width: 1.0, height: 1.0)
        cell.layer.shadowColor = UIColor(red: 157/255, green: 157/255, blue: 157/255, alpha: 1.0).cgColor
        
        cell.titleLabel.text = titleLabel![indexPath.row]
        
        if nationalityVC != nil{
            
            if navbarName == "Passport" || navbarName == "Passaporte" || navbarName == "Pasaporte"{
                
                if indexPath.row == 0{
                    cell.textAuxiliar = data1[index].documentsAdults!
                    text.append(cell.textAuxiliar)
                    
                } else if indexPath.row == 1{
                    cell.textAuxiliar = data1[index].documentsMinors!
                    text.append(cell.textAuxiliar)
                    
                } else if indexPath.row == 2{
                    cell.textAuxiliar = data1[index].procedure!
                    text.append(cell.textAuxiliar)
                    
                } else if indexPath.row == 3{
                    cell.textAuxiliar = data1[index].location1!
                    text.append(cell.textAuxiliar)
                    
                } else if indexPath.row == 4{
                    cell.textAuxiliar = data1[index].location2!
                    
                    if cell.textAuxiliar == "NULL"{
                        cell.textAuxiliar = "There's no others locations to do the procedure."
                    }
                    
                    text.append(cell.textAuxiliar)
                    
                } else if indexPath.row == 5{
                    cell.textAuxiliar = data1[index].cost!
                    text.append(cell.textAuxiliar)
                    
                } else if indexPath.row == 6{
                    cell.textAuxiliar = data1[index].vality!
                    text.append(cell.textAuxiliar)
                    
                } else if indexPath.row == 7{
                    cell.textAuxiliar = data1[index].others!
                    text.append(cell.textAuxiliar)
                    
                    if cell.textAuxiliar == "NULL"{
                        cell.textAuxiliar = "There's no others informations available."
                    }
                    
                    text.append(cell.textAuxiliar)
                }
            }
            
            guard dicImage[cell.titleLabel.text!] != nil else {return UITableViewCell()}
            
            cell.degradeView.image = UIImage(named: "\(imageName) \(indexPath.row+1)t.pdf")
            cell.iconImage.image = iconImage
            cell.textAuxiliar = text[indexPath.row]
            
        } else{
            
            if indexPath.row == 0{
                cell.textAuxiliar = data2[index].warningText1!
                text.append(cell.textAuxiliar)
                
            } else if indexPath.row == 1{
                cell.textAuxiliar = data2[index].warningText2!
                text.append(cell.textAuxiliar)
                
            } else if indexPath.row == 2{
                cell.textAuxiliar = data2[index].warningText3!
                text.append(cell.textAuxiliar)
                
            }
            
            cell.iconImage.image = UIImage(named: "Generalwarningicon.pdf")
            cell.seeAllView.layer.borderColor = destinationCountry
            cell.seeAllView.layer.borderWidth = 2.0
            cell.titleLabel.textColor = UIColor.black
        }

        return cell
    }
    
    
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 105
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "seeAllCardsSegue"{
            
            let selectedTitle = (sender as! SeeAllTableViewCell).titleLabel.text!
            let selectedText = (sender as! SeeAllTableViewCell).textAuxiliar
            
            let destinationViewController = segue.destination as! CardViewController
            destinationViewController.titleLabel = selectedTitle
            destinationViewController.text = selectedText
            destinationViewController.image = UIImage(named: "\(imageName) 1.pdf")
            destinationViewController.parentVC = self
            tabBarController?.tabBar.isHidden = true
            
            if nationalityVC == nil{
                destinationViewController.color = "black"
                destinationViewController.text = selectedText
                destinationViewController.borderColor = borderColor
            
            } else{
                destinationViewController.imageName = imageName
            }
            
        }
    }

}

// seeAllCard
