//
//  MyTips+CoreDataClass.swift
//  Traveling+
//
//  Created by Zewu Chen on 24/05/19.
//  Copyright © 2019 Leonardo Oliveira. All rights reserved.
//
//

import Foundation
import CoreData


public class MyTips: NSManagedObject {

}
